"""
AWS Glue Job: Gold Layer
Reads from Silver Iceberg tables (S3 Tables), writes aggregated business
metrics to Gold Iceberg tables, also on S3 Tables (managed Iceberg).
"""

import sys
import logging
import boto3
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql import SparkSession

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

args = getResolvedOptions(sys.argv, [
    'JOB_NAME', 'database_name', 'data_lake_bucket',
    'gold_table_bucket_arn', 'aws_region'
])

BUCKET = args['data_lake_bucket']
GOLD_TABLE_BUCKET_ARN = args['gold_table_bucket_arn']
AWS_REGION = args.get('aws_region', 'us-east-1')

arn_parts = GOLD_TABLE_BUCKET_ARN.split(":")
ACCOUNT_ID = arn_parts[4]
TABLE_BUCKET_NAME = arn_parts[5].split("/")[1]

DB_SILVER = "ecommerce_silver"
DB_GOLD   = "ecommerce_gold"
S3T_CAT   = "s3tablescatalog"

sc = SparkContext()
glueContext = GlueContext(sc)

# TODO 1: Configure Spark with S3 Tables catalog (same pattern as silver)
spark = (
    SparkSession.builder
    .config("spark.sql.extensions",
            "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
    .config(f"spark.sql.catalog.{S3T_CAT}",
            "org.apache.iceberg.spark.SparkCatalog")
    .config(f"spark.sql.catalog.{S3T_CAT}.catalog-impl",
            "org.apache.iceberg.aws.glue.GlueCatalog")
    .config(f"spark.sql.catalog.{S3T_CAT}.glue.id",
            f"{ACCOUNT_ID}:s3tablescatalog/{TABLE_BUCKET_NAME}")
    .config(f"spark.sql.catalog.{S3T_CAT}.warehouse",
            f"s3://{BUCKET}/gold-warehouse/")
    .getOrCreate()
)

job = Job(glueContext)
job.init(args['JOB_NAME'], args)

logger.info(f"S3 Tables catalog: {S3T_CAT} → {TABLE_BUCKET_NAME}")
logger.info(f"Reading silver from: {S3T_CAT}.{DB_SILVER}")
logger.info(f"Writing gold to: {S3T_CAT}.{DB_GOLD}")

# TODO 2: Create gold namespace via boto3
glue_client = boto3.client('glue', region_name=AWS_REGION)
try:
    glue_client.create_database(
        CatalogId=f"{ACCOUNT_ID}:s3tablescatalog/{TABLE_BUCKET_NAME}",
        DatabaseInput={'Name': DB_GOLD}
    )
    logger.info(f"Created namespace: {DB_GOLD}")
except Exception as e:
    logger.info(f"Namespace already exists: {e}")


def create_gold_table(name, query):
    """Query silver, drop existing, write to S3 Tables gold namespace."""
    fqn = f"{S3T_CAT}.{DB_GOLD}.{name}"

    # TODO 3: Same DROP-PURGE / writeTo().create() pattern as silver
    df = spark.sql(query)
    logger.info(f"{name}: {df.count()} rows to write")
    spark.sql(f"DROP TABLE IF EXISTS {fqn} PURGE")
    df.writeTo(fqn).using("iceberg").tableProperty("format-version", "2").create()
    logger.info(f"Written: {fqn}")


# TODO 4: customer_analytics — monthly aggregation from silver.order_details
create_gold_table("customer_analytics", f"""
    SELECT
        DATE_TRUNC('month', order_date)                                         AS analysis_month,
        COUNT(DISTINCT user_id)                                                 AS total_customers,
        COUNT(DISTINCT CASE WHEN customer_order_sequence = 1
                            THEN user_id END)                                   AS new_customers,
        COUNT(DISTINCT CASE WHEN customer_order_sequence > 1
                            THEN user_id END)                                   AS returning_customers,
        COUNT(order_id)                                                         AS total_orders,
        ROUND(SUM(total_amount), 2)                                             AS total_revenue,
        ROUND(AVG(total_amount), 2)                                             AS avg_order_value,
        COUNT(CASE WHEN customer_segment = 'New'    THEN 1 END)                 AS new_customer_orders,
        COUNT(CASE WHEN customer_segment = 'Repeat' THEN 1 END)                 AS repeat_customer_orders,
        COUNT(CASE WHEN customer_segment = 'Loyal'  THEN 1 END)                 AS loyal_customer_orders,
        COUNT(CASE WHEN customer_segment = 'VIP'    THEN 1 END)                 AS vip_customer_orders,
        COUNT(DISTINCT city)                                                    AS cities_served,
        COUNT(DISTINCT state)                                                   AS states_served,
        ROUND(SUM(CASE WHEN customer_segment = 'New'    THEN total_amount END), 2)
                                                                                AS new_customer_revenue,
        ROUND(SUM(CASE WHEN customer_segment = 'VIP'    THEN total_amount END), 2)
                                                                                AS vip_customer_revenue,
        ROUND(SUM(CASE WHEN customer_segment = 'Loyal'  THEN total_amount END), 2)
                                                                                AS loyal_customer_revenue,
        ROUND(AVG(customer_lifetime_value), 2)                                  AS avg_customer_lifetime_value,
        current_timestamp()                                                     AS gold_processed_at
    FROM {S3T_CAT}.{DB_SILVER}.order_details
    GROUP BY DATE_TRUNC('month', order_date)
    ORDER BY analysis_month
""")

# TODO 5: realtime_metrics — hourly aggregation from silver.enriched_events
create_gold_table("realtime_metrics", f"""
    SELECT
        DATE_TRUNC('hour', event_timestamp)                                     AS metric_hour,
        COUNT(event_id)                                                         AS total_events,
        COUNT(DISTINCT user_name)                                               AS unique_users,
        COUNT(DISTINCT session_id)                                              AS unique_sessions,
        COUNT(CASE WHEN event_type = 'page_view'   THEN 1 END)                 AS page_views,
        COUNT(CASE WHEN event_type = 'add_to_cart' THEN 1 END)                 AS add_to_carts,
        COUNT(CASE WHEN event_type = 'purchase'    THEN 1 END)                 AS purchases,
        COUNT(CASE WHEN event_type = 'click'       THEN 1 END)                 AS clicks,
        ROUND(SUM(CASE WHEN event_type = 'purchase' THEN revenue END), 2)      AS hourly_revenue,
        ROUND(AVG(CASE WHEN event_type = 'purchase' THEN revenue END), 2)      AS avg_purchase_value,
        COUNT(CASE WHEN source = 'google'   THEN 1 END)                        AS google_traffic,
        COUNT(CASE WHEN source = 'facebook' THEN 1 END)                        AS facebook_traffic,
        COUNT(CASE WHEN source = 'direct'   THEN 1 END)                        AS direct_traffic,
        COUNT(DISTINCT product_category)                                        AS categories_viewed,
        current_timestamp()                                                     AS gold_processed_at
    FROM {S3T_CAT}.{DB_SILVER}.enriched_events
    WHERE event_date >= DATE '2024-01-01'
    GROUP BY DATE_TRUNC('hour', event_timestamp)
    ORDER BY metric_hour
""")

logger.info("Gold layer complete — tables written to S3 Tables")
job.commit()
