"""
AWS Glue Job: Silver Layer
Reads from Bronze Iceberg tables (Glue Catalog on S3), writes enriched/joined
Silver tables to S3 Tables (managed Iceberg).
"""

import sys
import logging
import boto3
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql import SparkSession

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

args = getResolvedOptions(sys.argv, [
    'JOB_NAME', 'database_name', 'data_lake_bucket',
    'gold_table_bucket_arn', 'aws_region'
])

DB_BRONZE = args['database_name']
BUCKET = args['data_lake_bucket']
GOLD_TABLE_BUCKET_ARN = args['gold_table_bucket_arn']
AWS_REGION = args.get('aws_region', 'us-east-1')

arn_parts = GOLD_TABLE_BUCKET_ARN.split(":")
ACCOUNT_ID = arn_parts[4]
TABLE_BUCKET_NAME = arn_parts[5].split("/")[1]

DB_SILVER = "ecommerce_silver"
CATALOG = "glue_catalog"
S3T_CAT = "s3tablescatalog"

sc = SparkContext()
glueContext = GlueContext(sc)

# TODO 1: Configure Spark with the S3 Tables catalog using SparkSession.builder
spark = (
    SparkSession.builder
    .config("spark.sql.extensions",
            "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
    .config(f"spark.sql.catalog.{S3T_CAT}",
            "org.apache.iceberg.spark.SparkCatalog")
    .config(f"spark.sql.catalog.{S3T_CAT}.catalog-impl",
            "org.apache.iceberg.aws.glue.GlueCatalog")
    .config(f"spark.sql.catalog.{S3T_CAT}.glue.id",
            f"{ACCOUNT_ID}:s3tablescatalog/{TABLE_BUCKET_NAME}")
    .config(f"spark.sql.catalog.{S3T_CAT}.warehouse",
            f"s3://{BUCKET}/silver-warehouse/")
    .getOrCreate()
)

job = Job(glueContext)
job.init(args['JOB_NAME'], args)

logger.info(f"S3 Tables catalog: {S3T_CAT} → {TABLE_BUCKET_NAME}")
logger.info(f"Reading bronze from: {CATALOG}.{DB_BRONZE}")

# TODO 2: Create silver namespace via boto3 (not Spark SQL)
glue_client = boto3.client('glue', region_name=AWS_REGION)
try:
    glue_client.create_database(
        CatalogId=f"{ACCOUNT_ID}:s3tablescatalog/{TABLE_BUCKET_NAME}",
        DatabaseInput={'Name': DB_SILVER}
    )
    logger.info(f"Created namespace: {DB_SILVER}")
except Exception as e:
    logger.info(f"Namespace already exists: {e}")


def create_silver_table(name, query):
    """Query bronze, drop existing, write to S3 Tables silver namespace."""
    fqn = f"{S3T_CAT}.{DB_SILVER}.{name}"

    # TODO 3: Execute query, DROP PURGE, writeTo().create()
    df = spark.sql(query)
    logger.info(f"{name}: {df.count()} rows to write")
    spark.sql(f"DROP TABLE IF EXISTS {fqn} PURGE")
    df.writeTo(fqn).using("iceberg").tableProperty("format-version", "2").create()
    logger.info(f"Written: {fqn}")


# TODO 4: order_details
create_silver_table("order_details", f"""
    SELECT
        o.order_id,
        o.user_id,
        o.total_amount,
        CAST(o.created_at AS DATE)                                      AS order_date,
        DATE_FORMAT(o.created_at, 'yyyy-MM')                            AS order_month,
        CONCAT(u.first_name, ' ', u.last_name)                         AS customer_name,
        u.email,
        u.city,
        u.state,
        CAST(u.created_at AS DATE)                                      AS registration_date,
        COUNT(*) OVER (
            PARTITION BY o.user_id
            ORDER BY o.created_at
            ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
        )                                                               AS customer_order_sequence,
        SUM(o.total_amount) OVER (
            PARTITION BY o.user_id
            ORDER BY o.created_at
            ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
        )                                                               AS customer_lifetime_value,
        CASE
            WHEN o.total_amount < 50   THEN 'Low'
            WHEN o.total_amount < 200  THEN 'Medium'
            WHEN o.total_amount < 500  THEN 'High'
            ELSE 'Premium'
        END                                                             AS order_value_segment,
        CASE
            WHEN COUNT(*) OVER (PARTITION BY o.user_id) = 1   THEN 'New'
            WHEN COUNT(*) OVER (PARTITION BY o.user_id) <= 3  THEN 'Repeat'
            WHEN COUNT(*) OVER (PARTITION BY o.user_id) <= 10 THEN 'Loyal'
            ELSE 'VIP'
        END                                                             AS customer_segment,
        DAYOFWEEK(o.created_at)                                         AS order_day_of_week,
        HOUR(o.created_at)                                              AS order_hour,
        current_timestamp()                                             AS silver_processed_at
    FROM {CATALOG}.{DB_BRONZE}.orders o
    JOIN {CATALOG}.{DB_BRONZE}.users  u ON o.user_id = u.id
    WHERE o.is_deleted IS NULL OR o.is_deleted = false
""")

# TODO 5: enriched_events
create_silver_table("enriched_events", f"""
    SELECT
        e.event_id,
        e.session_id,
        e.page_url,
        e.source,
        e.event_type,
        e.event_timestamp,
        CONCAT(u.first_name, ' ', u.last_name)                         AS user_name,
        u.email                                                         AS user_email,
        DATEDIFF(CAST(e.event_timestamp AS DATE), CAST(u.created_at AS DATE))
                                                                        AS days_since_registration,
        u.city                                                          AS user_city,
        u.state                                                         AS user_state,
        p.name                                                          AS product_name,
        p.category                                                      AS product_category,
        p.price                                                         AS product_price,
        CASE WHEN e.event_type = 'purchase' THEN p.price ELSE NULL END  AS revenue,
        COUNT(*) OVER (
            PARTITION BY e.session_id
            ORDER BY e.event_timestamp
        )                                                               AS event_sequence_in_session,
        HOUR(e.event_timestamp)                                         AS event_hour,
        DAYOFWEEK(e.event_timestamp)                                    AS event_day_of_week,
        CAST(e.event_timestamp AS DATE)                                 AS event_date
    FROM {CATALOG}.{DB_BRONZE}.events    e
    LEFT JOIN {CATALOG}.{DB_BRONZE}.users    u ON e.user_id    = u.id
    LEFT JOIN {CATALOG}.{DB_BRONZE}.products p ON e.product_id = p.id
    WHERE CAST(e.event_timestamp AS DATE) >= DATE '2024-01-01'
""")

# TODO 6: product_performance
create_silver_table("product_performance", f"""
    SELECT
        p.id                                                            AS product_id,
        p.name                                                          AS product_name,
        p.category,
        p.price,
        p.stock_quantity,
        p.is_active,
        COUNT(CASE WHEN e.event_type = 'page_view'   THEN 1 END)       AS page_views,
        COUNT(CASE WHEN e.event_type = 'add_to_cart' THEN 1 END)       AS add_to_carts,
        COUNT(CASE WHEN e.event_type = 'purchase'    THEN 1 END)       AS purchases,
        COUNT(CASE WHEN e.event_type = 'click'       THEN 1 END)       AS clicks,
        COUNT(e.event_id)                                               AS total_events,
        COUNT(DISTINCT e.user_id)                                       AS unique_visitors,
        COUNT(DISTINCT e.session_id)                                    AS unique_sessions,
        SUM(CASE WHEN e.event_type = 'purchase' THEN e.order_value ELSE 0 END)
                                                                        AS total_revenue,
        AVG(CASE WHEN e.event_type = 'purchase' THEN e.order_value END)
                                                                        AS avg_purchase_value,
        ROUND(
            COUNT(CASE WHEN e.event_type = 'purchase' THEN 1 END) * 100.0
            / NULLIF(COUNT(CASE WHEN e.event_type = 'page_view' THEN 1 END), 0),
        2)                                                              AS view_to_purchase_rate,
        ROUND(
            COUNT(CASE WHEN e.event_type = 'purchase' THEN 1 END) * 100.0
            / NULLIF(COUNT(CASE WHEN e.event_type = 'add_to_cart' THEN 1 END), 0),
        2)                                                              AS cart_to_purchase_rate
    FROM {CATALOG}.{DB_BRONZE}.products p
    LEFT JOIN {CATALOG}.{DB_BRONZE}.events e ON p.id = e.product_id
    GROUP BY p.id, p.name, p.category, p.price, p.stock_quantity, p.is_active
""")

logger.info("Silver layer complete")
job.commit()
