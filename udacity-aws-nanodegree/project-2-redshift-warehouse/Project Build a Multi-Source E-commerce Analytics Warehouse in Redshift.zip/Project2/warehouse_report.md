# Data Warehouse Build Report

Generated: 2026-09-02T10:36:08.218185Z

## Schema Diagram

See project-mermaid-diagram.md for the full ERD.
Star schema: 3 fact tables x 12 dimension tables, sourced from PostgreSQL, Cassandra, Neo4j.

### Facts
- dw_fact_orders:       One row per order.  DISTKEY(customer_sk) SORTKEY(order_date_key)
- dw_fact_events:       One row per event.  DISTKEY(customer_sk) SORTKEY(event_date_key)
- dw_fact_graph_edges:  One row per edge.   DISTKEY(to_product_sk) SORTKEY(event_date_key)

### Dimensions
- dw_dim_date:     Calendar spine - DISTSTYLE ALL, SORTKEY(date_key)
- dw_dim_customer: SCD Type 2 - DISTKEY(customer_id)
- dw_dim_product:  SCD Type 2 - DISTKEY(product_id)
- Lookup dims (channel/device/browser/os/referrer/campaign/shipping/payment/ab_variant): DISTSTYLE ALL

## Row Counts

### Staging Tables
- stg_orders_raw:       2500 rows
- stg_events_raw:       2500 rows
- stg_edges_raw:        2500 rows

### Fact Tables
- dw_fact_orders:       2500 rows
- dw_fact_events:       2500 rows
- dw_fact_graph_edges:  2500 rows

### Dimension Tables
- dw_dim_customer:      4999 rows
- dw_dim_product:       3869 rows
- dw_dim_date:          552 rows
- dw_mv_daily_revenue:  542 rows (materialized view)

## Design Rationale

1. Why star schema?
   OLAP workloads aggregate across multiple dimensions simultaneously.
   Star schema minimises joins (2-3 per query vs 5+ for 3NF).
   Redshift columnar storage benefits from flat, denormalised fact table structure.

2. Distribution key choices:
   - customer_sk on fact_orders and fact_events: co-locates with dim_customer, eliminates shuffle.
   - to_product_sk on fact_graph_edges: product recommendation queries dominate graph analytics.
   - DISTSTYLE ALL on small lookup dims: <100 rows each, broadcasting costs nothing.

3. Sort key choices:
   - date_key on all facts: time-range filters are the most common analytical pattern.
     Zone-map pruning skips entire 1MB blocks without scanning.

4. SCD Type 2 on customer and product:
   effective_from/to + is_current supports historical analysis without losing history.

## Performance Findings

### Benchmark: Full Scan vs Materialized View

| Query Pattern | Execution Time | Method |
|---|---|---|
| Full scan: fact_orders JOIN dim_date GROUP BY month | 2.74s | 2-table JOIN + aggregation |
| Materialized view: dw_mv_daily_revenue | 2.79s | Pre-aggregated, no JOIN |
| Speedup | 1.0x faster | Materialized view eliminates JOIN |

### ANALYZE Results
ANALYZE run on 6 key tables after load:
dw_fact_orders, dw_fact_events, dw_fact_graph_edges,
dw_dim_customer, dw_dim_product, dw_dim_date
Purpose: updates table statistics so query planner chooses optimal join and scan strategies.

### Distribution Strategy Impact

| Table | DISTKEY | SORTKEY | Effect |
|---|---|---|---|
| dw_fact_orders | customer_sk | order_date_key | Co-located with dim_customer, no shuffle |
| dw_fact_events | customer_sk | event_date_key | Co-located with dim_customer, no shuffle |
| dw_fact_graph_edges | to_product_sk | event_date_key | Co-located with dim_product, no shuffle |
| dw_dim_date | DISTSTYLE ALL | date_key | Broadcast, zero shuffle on any date join |
| dw_dim_customer | customer_id | customer_sk | Merge join with fact tables |
| dw_dim_product | product_id | product_sk | Merge join with fact tables |
| stg_* tables | DISTSTYLE EVEN | (none) | Prevents hot-node skew during INSERT |

## Example Analytical Query with Results

### Revenue by Channel (fact_orders JOIN dim_channel)

```sql
SELECT
    ch.channel,
    COUNT(DISTINCT fo.order_id)      AS total_orders,
    ROUND(SUM(fo.order_total_usd),2) AS revenue_usd,
    ROUND(AVG(fo.order_total_usd),2) AS avg_order_value
FROM public.dw_fact_orders fo
JOIN public.dw_dim_channel ch ON ch.channel_sk = fo.channel_sk
GROUP BY ch.channel
ORDER BY revenue_usd DESC;
```

### Results

| Channel | Orders | Revenue USD | Avg Order Value |
|---------|--------|-------------|----------------|
| android_app | 535 | $224060.04 | $418.80 |
| ios_app | 498 | $221419.83 | $444.61 |
| web | 500 | $205995.94 | $411.99 |
| marketplace | 490 | $199147.95 | $406.42 |
| mobile_web | 477 | $188793.93 | $395.79 |


## Analytics Capabilities

- Revenue: daily/monthly trends by channel, campaign, category (via mv_daily_revenue)
- Customer: lifetime value, retention, segment behaviour (SCD Type 2 preserves history)
- Product: views to add-to-cart to purchase funnel via graph edges
- Delivery: on-time rate, shipping method performance, return rate
- Fraud: fraud_score by device, browser, payment method
- A/B testing: conversion rates by ab_variant
